<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class Inventorycreate extends Component
{
    public function render()
    {
        return view('livewire.product.inventorycreate');
    }
}
