<?php echo e($slot); ?>

<?php /**PATH /home/iwebtech/public_html/estore/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>