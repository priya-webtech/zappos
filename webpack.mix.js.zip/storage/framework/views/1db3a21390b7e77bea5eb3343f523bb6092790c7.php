<a href="/">
    <img src="/assets/logo-blue-small._CB485919770_.svg" alt="logo" id="brand-identity" class="mx-auto d-block m-5">
</a>
<?php /**PATH D:\wamp\www\Estore\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>