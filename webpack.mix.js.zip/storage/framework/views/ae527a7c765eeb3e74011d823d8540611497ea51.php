<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/iwebtech/public_html/estore/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>