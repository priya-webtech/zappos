<div>
    <!-- He who is contented is rich. - Laozi -->
</div><?php /**PATH D:\wamp\www\Estore\storage\framework\views/ec4884bcb42677f86c1f270815089ae5a8a68f38.blade.php ENDPATH**/ ?>