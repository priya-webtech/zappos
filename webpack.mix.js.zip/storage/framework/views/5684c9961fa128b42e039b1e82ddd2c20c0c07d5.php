<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div wire:key="alert">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create')->html();
} elseif ($_instance->childHasBeenRendered('AvMBad1')) {
    $componentId = $_instance->getRenderedChildComponentId('AvMBad1');
    $componentTag = $_instance->getRenderedChildComponentTagName('AvMBad1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AvMBad1');
} else {
    $response = \Livewire\Livewire::mount('user.create');
    $html = $response->html();
    $_instance->logRenderedChild('AvMBad1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer.list-customers')->html();
} elseif ($_instance->childHasBeenRendered('MdAgWol')) {
    $componentId = $_instance->getRenderedChildComponentId('MdAgWol');
    $componentTag = $_instance->getRenderedChildComponentTagName('MdAgWol');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MdAgWol');
} else {
    $response = \Livewire\Livewire::mount('customer.list-customers');
    $html = $response->html();
    $_instance->logRenderedChild('MdAgWol', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php /**PATH D:\wamp\www\Estore\resources\views/livewire/customer/customers.blade.php ENDPATH**/ ?>