<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Shoes, Sneaker, Clothes &amp; Clothing')); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

    <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap"
          rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/uptown.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/responsive.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('/js/main.js')); ?>'"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>



</head>
<body>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.header', [])->html();
} elseif ($_instance->childHasBeenRendered('JqBCHGc')) {
    $componentId = $_instance->getRenderedChildComponentId('JqBCHGc');
    $componentTag = $_instance->getRenderedChildComponentTagName('JqBCHGc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JqBCHGc');
} else {
    $response = \Livewire\Livewire::mount('admin.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('JqBCHGc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="admin_panel_wraper">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.nav', [])->html();
} elseif ($_instance->childHasBeenRendered('7cIk6hb')) {
    $componentId = $_instance->getRenderedChildComponentId('7cIk6hb');
    $componentTag = $_instance->getRenderedChildComponentTagName('7cIk6hb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7cIk6hb');
} else {
    $response = \Livewire\Livewire::mount('admin.nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('7cIk6hb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="panel_content">
        <main>
            <?php echo e($slot); ?>

        </main>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>



</body>
</html>



<?php /**PATH /home/iwebtech/public_html/estore/resources/views/layouts/admin.blade.php ENDPATH**/ ?>