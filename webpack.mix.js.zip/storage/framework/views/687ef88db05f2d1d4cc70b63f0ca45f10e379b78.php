<?php echo e($slot); ?>

<?php /**PATH D:\wamp\www\Estore\resources\views/layouts/app.blade.php ENDPATH**/ ?>