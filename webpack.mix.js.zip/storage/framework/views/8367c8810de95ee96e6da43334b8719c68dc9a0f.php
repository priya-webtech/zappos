<?php echo e($slot); ?>

<?php /**PATH /home/iwebtech/public_html/estore/resources/views/layouts/app.blade.php ENDPATH**/ ?>