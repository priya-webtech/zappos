<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div wire:key="alert">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create')->html();
} elseif ($_instance->childHasBeenRendered('yOo8KAD')) {
    $componentId = $_instance->getRenderedChildComponentId('yOo8KAD');
    $componentTag = $_instance->getRenderedChildComponentTagName('yOo8KAD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yOo8KAD');
} else {
    $response = \Livewire\Livewire::mount('user.create');
    $html = $response->html();
    $_instance->logRenderedChild('yOo8KAD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.list-users')->html();
} elseif ($_instance->childHasBeenRendered('jAOQZAm')) {
    $componentId = $_instance->getRenderedChildComponentId('jAOQZAm');
    $componentTag = $_instance->getRenderedChildComponentTagName('jAOQZAm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jAOQZAm');
} else {
    $response = \Livewire\Livewire::mount('user.list-users');
    $html = $response->html();
    $_instance->logRenderedChild('jAOQZAm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php /**PATH /home/iwebtech/public_html/estore/resources/views/livewire/user/users.blade.php ENDPATH**/ ?>