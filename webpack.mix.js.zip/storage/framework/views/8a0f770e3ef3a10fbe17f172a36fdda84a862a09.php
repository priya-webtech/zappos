<div class="admin_panel_header">
    <div class="header_site_name">
        <div class="hidden_desktop">
            <div class="open_side_menu mr-2 fs-20"><i class="fas fa-bars"></i></div>
        </div>
        <a href="#" class="site_title">Demo Estore</a>
    </div>
    <div class="header_site_search hidden_mobile">
        <form name="panel_search" id="panel_search" method="post">
            <button type="submit"><i class="fas fa-search"></i></button>
            <input type="text" name="search_from_panel" id="search_from_panel" placeholder="Search">
        </form>
    </div>
    <div class="header_user_name">

        <a href="#" class="header_user_profile">
            <img src="/assets/images/avatar.png">
            <h4>Demo Estore</h4>
        </a>
    </div>
</div>
<?php /**PATH D:\wamp\www\Estore\resources\views/livewire/admin/header.blade.php ENDPATH**/ ?>