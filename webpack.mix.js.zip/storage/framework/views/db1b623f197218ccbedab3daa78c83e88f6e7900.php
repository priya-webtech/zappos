<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div wire:key="alert">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.create')->html();
} elseif ($_instance->childHasBeenRendered('3pKeRh4')) {
    $componentId = $_instance->getRenderedChildComponentId('3pKeRh4');
    $componentTag = $_instance->getRenderedChildComponentTagName('3pKeRh4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3pKeRh4');
} else {
    $response = \Livewire\Livewire::mount('user.create');
    $html = $response->html();
    $_instance->logRenderedChild('3pKeRh4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer.list-customers')->html();
} elseif ($_instance->childHasBeenRendered('O9nHOvr')) {
    $componentId = $_instance->getRenderedChildComponentId('O9nHOvr');
    $componentTag = $_instance->getRenderedChildComponentTagName('O9nHOvr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O9nHOvr');
} else {
    $response = \Livewire\Livewire::mount('customer.list-customers');
    $html = $response->html();
    $_instance->logRenderedChild('O9nHOvr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php /**PATH /home/iwebtech/public_html/estore/resources/views/livewire/customer/customers.blade.php ENDPATH**/ ?>