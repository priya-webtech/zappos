<a href="/">
    <img src="<?php echo e(URL::asset('/assets/logo-blue-small._CB485919770_.svg')); ?>" alt="logo" id="brand-identity" class="mx-auto d-block m-5">
</a>
<?php /**PATH /home/iwebtech/public_html/estore/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>