<x-admin-layout>
    {!! Menu::render() !!}
    {!! Menu::scripts() !!}

</x-admin-layout>
