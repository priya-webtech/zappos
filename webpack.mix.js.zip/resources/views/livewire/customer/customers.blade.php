<x-admin-layout>
    <div wire:key="alert">
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session('message') }}
            </div>
        @endif
    </div>
    @livewire('user.create')
    @livewire('customer.list-customers')
</x-admin-layout>

