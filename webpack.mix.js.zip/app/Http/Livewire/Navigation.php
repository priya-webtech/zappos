<?php

namespace App\Http\Livewire;

use App\Models\Menu;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Navigation extends Component
{
    public $menu_arr = [];
    public function render()
    {
        $menus = Menu::with('items')->get();
        $i = 0;
        foreach ($menus as $menu) {
            $this->menu_arr[$i]['id'] = $menu->id;
            $this->menu_arr[$i]['name'] = $menu->name;
            $this->menu_arr[$i]['items'] = [];
            $this->menu_arr[$i]['images'] = [];
            foreach ($menu->items->sortBy('sort') as $item) {
                 if (!empty($item->image)) {
                     $this->menu_arr[$i]['images'][$item->id] = $item->toArray();

                } elseif ($item->depth == 0 && $item->image == '') {
                    $this->menu_arr[$i]['items'][$item->id] = $item->toArray();

                } elseif ($item->depth == 1 && $item->image == '') {
                    $this->menu_arr[$i]['items'][$item->parent]['items'][] = $item->toArray();
                }
            }
            $i++;
        }

        return view('livewire.navigation');
    }
}
