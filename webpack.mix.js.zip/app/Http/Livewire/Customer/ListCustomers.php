<?php

namespace App\Http\Livewire\Customer;

use App\Models\User;
use Livewire\Component;

class ListCustomers extends Component
{
    public $customers;
    protected $listeners = ['getCustomers'];

    public function render()
    {
        $this->getCustomers();
        return view('livewire.customer.list-customers');
    }

    public function getCustomers() {
        $this->customers = User::role('customer')->get();
    }
}
