<?php

namespace App\Http\Livewire\Setting;

use Livewire\Component;

class AlternativeProvidersDetail extends Component
{
    public function render()
    {
        return view('livewire.setting.alternative-providers-detail');
    }
}
