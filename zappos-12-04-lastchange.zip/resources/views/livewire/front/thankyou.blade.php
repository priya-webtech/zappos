<div>
    {{-- Care about people's approval and you will be their prisoner. --}}
    <x-customer-layout>


        <div class="thank-you-sec">
            <div class="container">
                <div class="col-12">
                    <img src="../assets/thank-you-icon.png">
                    <h1 class="h1">Thank You</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <a href="{{url('/')}}" class="site-btn"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Home</a>
                </div>
            </div>
        </div>
    	
    </x-customer-layout>
</div>
