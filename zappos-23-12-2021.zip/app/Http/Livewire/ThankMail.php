<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ThankMail extends Component
{
    public function render()
    {
        return view('livewire.thank-mail');
    }
}
