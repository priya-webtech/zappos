<?php

namespace App\Http\Livewire\Setting;

use Livewire\Component;

class Legal extends Component
{
    public function render()
    {
        return view('livewire.setting.legal');
    }
}
