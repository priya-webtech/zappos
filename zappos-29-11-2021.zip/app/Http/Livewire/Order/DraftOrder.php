<?php

namespace App\Http\Livewire\Order;

use Livewire\Component;

class DraftOrder extends Component
{
    public function render()
    {
        return view('livewire.order.draft-order');
    }
}
