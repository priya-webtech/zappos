<?php

namespace App\Http\Livewire\Role;

use Livewire\Component;

class CreateRole extends Component
{
    public function render()
    {
        return view('livewire.role.create-role');
    }
}
