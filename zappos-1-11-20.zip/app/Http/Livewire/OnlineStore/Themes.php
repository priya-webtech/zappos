<?php

namespace App\Http\Livewire\OnlineStore;

use Livewire\Component;

class Themes extends Component
{
    public function render()
    {
        return view('livewire.online-store.themes');
    }
}
