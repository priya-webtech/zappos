<div>
    {{-- Be like water. --}}
   
    <p>{{$data['name'] }}</p>
    <p>{{$data['message'] }}</p>
</div>
