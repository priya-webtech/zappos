<div>
    <x-admin-layout>
    
</x-admin-layout>
</div>
