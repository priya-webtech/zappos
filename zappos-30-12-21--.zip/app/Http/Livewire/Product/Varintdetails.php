<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class Varintdetails extends Component
{
    public function render()
    {
        return view('livewire.product.varintdetails');
    }
}
