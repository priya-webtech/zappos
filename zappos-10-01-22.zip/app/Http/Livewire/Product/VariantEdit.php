<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class VariantEdit extends Component
{
    public function render()
    {
        return view('livewire.product.variant-edit');
    }
}
