<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class GiftCardscreate extends Component
{
    public function render()
    {
        return view('livewire.product.gift-cardscreate');
    }
}
