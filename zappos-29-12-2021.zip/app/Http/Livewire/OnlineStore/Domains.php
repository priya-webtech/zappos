<?php

namespace App\Http\Livewire\OnlineStore;

use Livewire\Component;

class Domains extends Component
{
    public function render()
    {
        return view('livewire.online-store.domains');
    }
}
