<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class Transfersdetail extends Component
{
    public function render()
    {
        return view('livewire.product.transfersdetail');
    }
}
