<?php

namespace App\Http\Livewire\Marketing;

use Livewire\Component;

class Marketing extends Component
{
    public function render()
    {
        return view('livewire.marketing.marketing');
    }
}
