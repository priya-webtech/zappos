<?php

namespace App\Http\Livewire\AdminUser;

use Livewire\Component;

class UserDetail extends Component
{
    public function render()
    {
        return view('livewire.admin-user.user-detail');
    }
}
