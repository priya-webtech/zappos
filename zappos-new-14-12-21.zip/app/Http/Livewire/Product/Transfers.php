<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class Transfers extends Component
{
    public function render()
    {
        return view('livewire.product.transfers');
    }
}
