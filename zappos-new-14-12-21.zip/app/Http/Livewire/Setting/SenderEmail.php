<?php

namespace App\Http\Livewire\Setting;

use Livewire\Component;

class SenderEmail extends Component
{
    public function render()
    {
        return view('livewire.setting.sender-email');
    }
}
