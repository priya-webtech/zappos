<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class IssuegiftCardscreate extends Component
{
    public function render()
    {
        return view('livewire.product.issuegift-cardscreate');
    }
}
