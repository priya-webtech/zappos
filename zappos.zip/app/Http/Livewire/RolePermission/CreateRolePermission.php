<?php

namespace App\Http\Livewire\RolePermission;

use Livewire\Component;

class CreateRolePermission extends Component
{
    public function render()
    {
        return view('livewire.role-permission.create-role-permission');
    }
}
