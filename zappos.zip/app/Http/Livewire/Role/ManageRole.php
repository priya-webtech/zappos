<?php

namespace App\Http\Livewire\Role;

use Livewire\Component;

class ManageRole extends Component
{
    public function render()
    {
        return view('livewire.role.manage-role');
    }
}
