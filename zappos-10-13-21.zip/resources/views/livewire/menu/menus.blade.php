<x-admin-layout>

      {!! \Harimayco\Menu\Facades\Menu::render() !!}

      {!! Menu::scripts() !!}

</x-admin-layout>

