<?php

namespace App\Http\Livewire\Setting;

use Livewire\Component;

class Languages extends Component
{
    public function render()
    {
        return view('livewire.setting.languages');
    }
}
