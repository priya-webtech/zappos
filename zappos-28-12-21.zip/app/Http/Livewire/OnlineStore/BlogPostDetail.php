<?php

namespace App\Http\Livewire\OnlineStore;

use Livewire\Component;

class BlogPostDetail extends Component
{
    public function render()
    {
        return view('livewire.online-store.blog-post-detail');
    }
}
