<?php

namespace App\Http\Livewire\Order;

use Livewire\Component;

class DraftOrdersDetail extends Component
{
    public function render()
    {
        return view('livewire.order.draft-orders-detail');
    }
}
